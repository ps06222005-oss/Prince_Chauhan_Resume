---
name: Luminous Caustic Spectrum
colors:
  surface: '#0f1321'
  surface-dim: '#0f1321'
  surface-bright: '#353948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#171b2a'
  surface-container: '#1b1f2e'
  surface-container-high: '#252939'
  surface-container-highest: '#303444'
  on-surface: '#dfe1f6'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dfe1f6'
  inverse-on-surface: '#2c303f'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#45e3ce'
  on-tertiary: '#003731'
  tertiary-container: '#07c7b2'
  on-tertiary-container: '#004d44'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#62fae3'
  tertiary-fixed-dim: '#3cddc7'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005047'
  background: '#0f1321'
  on-background: '#dfe1f6'
  surface-variant: '#303444'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  code:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an ultra-high-end, future-forward visual environment tailored for world-class engineers, creative technologists, and systems architects. Rooted in deep midnight obsidian waters, the visual narrative mirrors bioluminescent abyssal currents illuminated by multi-spectral chromatic refractions. It merges the technological discipline of systems architecture with the tactile, fluid elegance of optical liquid glass.

### Design Aesthetics
- **Liquid Glass & Translucent Acrylic:** Deep, multi-layered structural surfaces defined by heavy background filtration, subtle chromatic dispersion, and high-gloss specular reflections along the top edges.
- **Iridescent Refraction:** Bioluminescent jewel accents (cyan, magenta, opal, and electric violet) emerge organically like caustic light patterns refracted through curved prism lenses.
- **Architectural Precision:** Razor-sharp typography and structural wire-thin alignments anchor the fluid visual effects, preventing the interface from feeling decorative or ephemeral.

## Colors

The color system is constructed on a dark light-absorbing baseline, illuminated by multi-spectral iridescence and high-luminance specular highlights.

### Hierarchy & Token Application
- **Base Canvas (`#070b19`):** The foundational midnight obsidian abyss. Used for root application containers and background viewports.
- **Surface Elevation Layers:**
  - `surface-base`: `#0d1527` with 70% opacity for low-tier paneling.
  - `surface-elevated`: `#131d38` with 55% opacity for cards, modals, and interactive controls.
  - `surface-highlight`: `#1e2b4d` with 40% opacity for hovered or active items.
- **Spectral Accents:**
  - **Primary (`#38bdf8` - Bioluminescent Cyan):** High-priority interactive triggers, focal typography, and active status indicators.
  - **Secondary (`#a855f7` - Prism Violet):** Secondary interactive actions, visual anchors, and refracted gradients pairing into `#ec4899`.
  - **Tertiary (`#2dd4bf` - Opal Teal):** System successes, algorithmic metrics, code callouts, and secondary indicators.
  - **Specular Incandescence (`#f0f9ff` / `rgba(255, 255, 255, 0.9)`):** Fine specular edges, crisp primary text, and focused points of simulated light reflection.

## Typography

The typographic hierarchy harmonizes technical clarity with modern geometric elegance. Space Grotesk establishes a technical, cutting-edge voice for hero moments, navigational cues, and labels, while Plus Jakarta Sans brings fluid, ergonomic legibility across body text and descriptions.

### Typographic Rules
- **Contrast & Legibility:** Large headlines employ negative letter-spacing for dense editorial presence.
- **Labeling & Metadata:** All labels (`label-md`, `label-sm`) default to uppercase styling with open tracking to balance against dense body blocks.
- **High-Incandescence Highlights:** Use pure white (`#f0f9ff`) on primary headlines and interactive labels; secondary text scales to desaturated cool indigos (`#94a3b8`) to preserve depth.

## Layout & Spacing

The layout model pairs a 12-column fluid grid on desktop viewports with deep dimensional breathing room. Spacing reinforces deliberate visual pacing, granting complex technical showcases room to breathe without clutter.

### Breakpoints & Adaptive Rhythm
- **Desktop (1024px+):** 12 columns, 1.5rem gutters, 2.5rem outer canvas margins. Components leverage wide panoramic spans with floating glass offsets.
- **Tablet (768px - 1023px):** 8 columns, 1.25rem gutters, 2rem margins. Cards consolidate into dual-column grids.
- **Mobile (below 768px):** 4 columns, 1rem gutters, 1.25rem margins. Multi-column cards stack vertically; structural headers compress to mobile typographic roles.

## Elevation & Depth

Visual depth is achieved through translucent acrylic layers, caustic optical boundaries, and ambient chromatic diffraction rather than traditional solid drop shadows.

### Glassmorphic Layering & Specular Reflections
- **Backdrop Filtration:** All elevated panels utilize a combined filter: `backdrop-filter: blur(16px) saturate(180%)`.
- **Specular Caustic Borders:** Boundaries do not use flat strokes. Instead, apply a directional gradient border using a 1px linear stroke fading from `rgba(255, 255, 255, 0.4)` and `#38bdf840` at the top edge down to `rgba(255, 255, 255, 0.03)` at the bottom edge.
- **Inner Rim Lighting:** Elevated interactive states apply an inner inset stroke: `box-shadow: inset 0 1px 1px 0 rgba(255, 255, 255, 0.25)`.
- **Chromatic Ambient Glow:** Cards in elevated or active states cast a diffused, tinted halo: `box-shadow: 0 20px 40px -15px rgba(7, 11, 25, 0.8), 0 0 35px -5px rgba(56, 189, 248, 0.15)`.

## Shapes

The design system embraces a smoothed curvature model (`roundedness: 2`). Standard elements adopt an 8px radius (`0.5rem`), transitioning to 16px (`1rem`) for larger project containers, and 24px (`1.5rem`) for high-level viewport modals.

### Curvature Geometry
- **Components & Controls:** 8px (`0.5rem`) keeps input forms, buttons, and code pills crisp and architectural.
- **Panels & Display Cards:** 16px (`1rem`) softens the refraction lines, mirroring precision-cut optical glass plates.
- **Pill Badges & Status Tags:** Pill geometry (`9999px`) is reserved exclusively for system tags, category chips, and live latency badges.

## Components

### Buttons
- **Primary:** Glass prism base (`rgba(56, 189, 248, 0.15)`) encased in a top-lit caustic border with cyan and magenta edge refractions. Text is `#f0f9ff` in `label-md`. On hover, the background saturates to `rgba(56, 189, 248, 0.3)` with an ambient chromatic glow (`0 0 24px rgba(56, 189, 248, 0.4)`).
- **Secondary / Ghost:** Clear acrylic background (`rgba(19, 29, 56, 0.4)`), a 1px uniform translucent outline (`rgba(255, 255, 255, 0.1)`), and text in `#94a3b8`. On hover, border color shifts to tertiary opal (`#2dd4bf`).

### Cards & Project Showcases
- Composed of 16px rounded surfaces with deep blue backing (`rgba(13, 21, 39, 0.65)`) layered over subtle radial gradient meshes.
- Border exhibits a dynamic light bleed: an ultra-subtle gradient spanning cyan `#38bdf8` to magenta `#ec4899` with an opacity cap of 30%.
- Includes an internal specular lip along the top edge for simulated glass thickness.

### Input Fields & Search Bars
- Background set to deep obsidian inset (`#070b19` with 80% opacity), inset shadow `inset 0 2px 4px rgba(0, 0, 0, 0.5)`.
- Border defaults to `rgba(255, 255, 255, 0.1)`. Focus state illuminates the border with a cyan glow (`#38bdf8`) and applies `box-shadow: 0 0 0 1px #38bdf8, 0 0 16px rgba(56, 189, 248, 0.25)`.

### Chips & Filter Pills
- Fully rounded pills (`9999px`) built with minimal translucent fills (`rgba(255, 255, 255, 0.05)`).
- Active state transitions into an iridescent cyan-to-teal gradient stroke with high-luminance white copy.

### Code Snippets & Terminal Blocks
- Deep midnight container (`#070b19`) framed by a 1px border of `#1e2b4d`.
- Integrated top navigation bar displaying glowing window controls and monospaced Space Grotesk metadata labels (`label-sm`).