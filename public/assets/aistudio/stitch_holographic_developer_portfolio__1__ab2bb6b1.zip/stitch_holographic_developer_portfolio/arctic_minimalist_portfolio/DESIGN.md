---
name: Arctic Minimalist Portfolio
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#4f565c'
  on-tertiary: '#ffffff'
  tertiary-container: '#676e75'
  on-tertiary-container: '#ebf1f9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#dde3eb'
  tertiary-fixed-dim: '#c1c7cf'
  on-tertiary-fixed: '#161c22'
  on-tertiary-fixed-variant: '#41474e'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system crafts an engineering-first personal brand for a high-caliber developer portfolio. It rejects dark cyberpunk tropes and generic corporate layouts in favor of an **Arctic Minimal / Pristine Studio** aesthetic: ultra-clean, clinical, razor-sharp, and technologically refined.

The visual direction draws from high-end hardware industrial design, modern research labs, and alpine daylight. It communicates intellectual rigor, meticulous attention to detail, and modern software craftsmanship. Interfaces should feel airy and luminous, punctuated by crisp optical borders, subtle frosted glass layers, and deliberate cobalt blue accents.

## Colors

The palette is rooted in an ultra-crisp arctic light spectrum.

- **Background Canvas (`#F8FAFC`)**: A cool, luminous off-white that prevents harsh retinal glare while preserving high dynamic contrast.
- **Surface Elevation (`#FFFFFF`)**: Pure alpine white for focal panels, interactive containers, and project tiles.
- **Primary Cobalt (`#2563EB`)**: An authoritative, focused blue reserved for key callouts, active states, and core technical metrics.
- **Secondary Sky (`#0EA5E9`)**: A glacial cyan-blue for secondary interaction cues, subtle live indicators, and hover accents.
- **Structural Neutral (`#E2E8F0`)**: Cool metallic tint used for subtle dividers, passive pills, and tonal shifts.
- **Core Contrast (`#0F172A`)**: Deep midnight slate for high-legibility headings and reading text.
- **Muted Contrast (`#64748B`)**: Glacier slate for metadata, tags, and secondary technical specifications.
- **Outlines (`#CBD5E1`)**: Precise, thin boundaries providing structural delineation without visual noise.

## Typography

Typographic scale balances architectural, geometric character (**Space Grotesk**) with neutral, high-density legibility (**Inter**).

- **Space Grotesk** commands the system’s structural hierarchy: headers, statistics, timeline dates, and technical labels. Its geometric personality injects precision and an unmistakable computational feel.
- **Inter** handles narrative flow, project breakdowns, role descriptions, and long-form technical writing, ensuring high legibility across resolutions.
- Uppercase tracking (`0.06em` to `0.08em`) is enforced on `label-md` and `label-sm` for system metrics, category tags, and status pills.

## Layout & Spacing

The layout adopts a 12-column responsive fluid grid anchored by a maximum container width of `1280px` to maintain focused visual scanning.

- **Desktop (>= 1024px)**: 12 columns, 1.5rem (`24px`) gutters, and 3rem (`48px`) outer margins. Sections are generously spaced using `space-xl` and larger multiples to project confidence, clarity, and breathing room.
- **Tablet (768px - 1023px)**: 8 columns, 1.25rem (`20px`) gutters, and 2rem (`32px`) margins. Multi-column showcase cards compress into 2-column or stacked formations.
- **Mobile (< 768px)**: 4 columns, 1rem (`16px`) gutters, and 1.25rem (`20px`) margins. Grids resolve to a single vertical column, preserving clear hierarchy through vertical cadence.

## Elevation & Depth

Visual hierarchy uses frosted glassmorphism, thin outlines, and soft studio ambient shadows rather than heavy drop shadows.

- **Layer 0 (Base)**: `#F8FAFC` matte surface.
- **Layer 1 (Card & Module Deck)**: `#FFFFFF` solid with a `1px` border of `#CBD5E1` and an ambient diffuse shadow (`box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)`).
- **Layer 2 (Floating Glass / Sticky Headers)**: Translucent surface using `rgba(255, 255, 255, 0.8)` layered with `backdrop-filter: blur(12px)` and a subtle light-catching edge (`border-bottom: 1px solid rgba(203, 213, 225, 0.7)`).
- **Interactive Hover Depth**: Cards transition vertically by `-2px` accompanied by a light shadow bloom (`box-shadow: 0 12px 30px -4px rgba(37, 99, 235, 0.08), 0 4px 10px -2px rgba(15, 23, 42, 0.04)`) and a border shift toward `#0EA5E9`.

## Shapes

The interface embraces a **Soft (Level 1)** radius architecture to preserve an engineered, crisp silhouette without looking starkly blunt.

- **Micro elements (Badges, Buttons, Inputs)**: `rounded` (`0.25rem` / `4px`) to `rounded-md` (`0.375rem` / `6px`).
- **Surface containers (Cards, Code Blocks, Panels)**: `rounded-lg` (`0.5rem` / `8px`).
- **Feature Modals & Overlay Drawers**: `rounded-xl` (`0.75rem` / `12px`).
- **Status indicators & avatars**: Fully circular (`rounded-full`) to offer organic contrast against the geometric grid.

## Components

### Buttons
- **Primary Action**: Background `#2563EB`, text `#FFFFFF`, subtle gradient overlay to `#1D4ED8` on hover. `0.5rem` radius, `0.625rem 1.25rem` padding. Space Grotesk text with tracking.
- **Secondary / Ghost**: Background `rgba(255, 255, 255, 0.8)`, border `1px solid #CBD5E1`, text `#0F172A`. Hover transitions border to `#2563EB` and text to `#2563EB`.
- **Icon / Terminal Triggers**: Monospace-centered squircle buttons with `#E2E8F0` backgrounds and `#0F172A` iconography.

### Cards & Project Showcases
- White containers (`#FFFFFF`) with a `1px` border (`#CBD5E1`), padded with `1.5rem`.
- Header areas feature Space Grotesk labels alongside GitHub/demo micro-links.
- Bottom metadata slots hold dynamic tech stack badges separated by a `1px` horizontal `#E2E8F0` divider.

### Chips & Badges
- **Tech Stack Badges**: Background `#F8FAFC`, border `1px solid #E2E8F0`, text `#64748B`, font `label-sm`.
- **Status Indicator**: Frosted pill with a pulsing `6px` emerald or cobalt dot (`#0EA5E9`) signaling availability for hire or active system status.

### Form Inputs & Terminal Elements
- **Input Fields**: Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F172A`. Focused state applies `border-color: #2563EB` with an ambient glow (`box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12)`).
- **Code & Snippet Blocks**: Background `#F8FAFC`, border `1px solid #CBD5E1`, top header displaying mock file paths in `label-sm`, syntax tinted in slate, cobalt, and sky.

### Lists & Timeline (Experience / Education)
- Clean vertical line (`1px` `#E2E8F0`) with solid `#FFFFFF` nodes framed by a `2px` `#2563EB` border.
- Milestone items highlight company/role in `Space Grotesk` with supporting outcomes in `Inter`.